from .wav2lip_v2 import Wav2Lip, Wav2Lip_disc_qual
from .syncnet import SyncNet_color