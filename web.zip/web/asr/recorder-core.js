/*
запись аудио
*/
(function(factory){
	factory(window);
	//umd returnExports.js
	if(typeof(define)=='function' && define.amd){
		define(function(){
			return Recorder;
		});
	};
	if(typeof(module)=='object' && module.exports){
		module.exports=Recorder;
	};
}(function(window){
"use strict";

var NOOP=function(){};

var Recorder=function(set){
	return new initFn(set);
};
Recorder.LM="2023-02-01 18:05";
var RecTxt="Recorder";
var getUserMediaTxt="getUserMedia";
var srcSampleRateTxt="srcSampleRate";
var sampleRateTxt="sampleRate";
var CatchTxt="catch";


//Включена глобальную запись микрофона
// Все готово, осталось только получить аудиоданные.
Recorder.IsOpen=function(){
	var stream=Recorder.Stream;
	if(stream){
		var tracks=stream.getTracks&&stream.getTracks()||stream.audioTracks||[];
		var track=tracks[0];
		if(track){
			var state=track.readyState;
			return state=="live"||state==track.LIVE;
		};
	};
	return false;
};
/*
    Размер буфера AudioContext во время записи H5.
    Это повлияет на скорость вызова onProcess во время записи H5.
    По сравнению с AudioContext.sampleRate=48000, 4096 близко к 12 кадрам/с.
    Регулировка этого параметра может создать более плавную анимацию обратного вызова.
	Значение может быть 256, 512, 1024, 2048, 4096, 8192 или 16384.
	Обратите внимание, что значение не может быть слишком низким. Начиная со значения 2048,
	частота обратных вызовов различных браузеров может не соответствовать,
	что приведет к проблемам с качеством звука.
	一 Обычно никаких настроек не требуется.
	После настройки сначала нужно закрыть открытую запись, а затем снова открыть ее,
	чтобы изменения вступили в силу.
*/
Recorder.BufferSize=4096;
//Уничтожает все удерживаемые глобальные ресурсы.
// Этот метод необходимо вызывать явно, когда Recorder нужно полностью удалить.
Recorder.Destroy=function(){
	CLog(RecTxt+" Destroy");
	Disconnect();// Отключает все глобальные потоки и ресурсы, которые только могут существовать.
	
	for(var k in DestroyList){
		DestroyList[k]();
	};
};
var DestroyList={};
//Зарегистрировать метод обработки, который должен уничтожить мировые ресурсы
Recorder.BindDestroy=function(key,call){
	DestroyList[key]=call;
};
// Поддерживает ли браузер запись и может ли он вызвать ее в любое время.
// Примечание: это позволяет только определить поддержку браузера,
// причём не определяет и не вызывает авторизацию пользователя,
// а также определяет, поддерживается ли некоторые определенные форматы записи.
Recorder.Support=function(){
	var scope=navigator.mediaDevices||{};
	if(!scope[getUserMediaTxt]){
		scope=navigator;
		scope[getUserMediaTxt]||(scope[getUserMediaTxt]=scope.webkitGetUserMedia||scope.mozGetUserMedia||scope.msGetUserMedia);
	};
	if(!scope[getUserMediaTxt]){
		return false;
	};
	Recorder.Scope=scope;
	
	if(!Recorder.GetContext()){
		return false;
	};
	return true;
};
// Получить глобальный объект AudioContext.
// Если браузер его не поддерживает, будет возвращено значение null.
Recorder.GetContext=function(){
	var AC=window.AudioContext;
	if(!AC){
		AC=window.webkitAudioContext;
	};
	if(!AC){
		return null;
	};
	
	if(!Recorder.Ctx||Recorder.Ctx.state=="closed"){
		//Невозможно построить повторно, нижний номер версии аппаратных контекстов достиг максимума (6)
		Recorder.Ctx=new AC();
		
		Recorder.BindDestroy("Ctx",function(){
			var ctx=Recorder.Ctx;
			if(ctx&&ctx.close){//Если можешь выключить — выключи. Если не можешь выключить — оставь.
				ctx.close();
				Recorder.Ctx=0;
			};
		});
	};
	return Recorder.Ctx;
};


/*Включать ли MediaRecorder.WebM.PCM для подключения аудиозахвата (если поддерживается браузером). По умолчанию включено. Если отключено или не поддерживается, для подключения будет использоваться AudioWorklet или ScriptProcessor. Аудиоданные, собираемые MediaRecorder, лучше, чем другими методами, и почти нет потери кадров, поэтому качество звука будет намного лучше. Рекомендуется оставить его включенным*/
var ConnectEnableWebM="ConnectEnableWebM";
Recorder[ConnectEnableWebM]=true;

/* Включать ли функцию AudioWorklet для подключения к аудиоприему (если браузер ее поддерживает).
По умолчанию она отключена. Если она отключена или не поддерживается,
для подключения будет использоваться устаревший ScriptProcessor (если метод все еще существует).
Текущая реализация AudioWorklet не так надежна, как ScriptProcessor на мобильных терминалах.
Если ConnectEnableWebM включен и действителен, этот параметр не будет иметь никакого эффекта.
*/
var ConnectEnableWorklet="ConnectEnableWorklet";
Recorder[ConnectEnableWorklet]=false;

/*
Инициализируйте соединение для захвата звука H5.
Если вы предоставите sourceStream самостоятельно, будет выполнен только простой процесс подключения.
Если это обычная запись микрофона, то поток в это время является глобальным.
После отключения в Safari его нельзя повторно подключить и использовать, что выглядит бесшумно.
Поэтому используйте глобальную обработку, чтобы избежать вызова отключения;
глобальная обработка также способствует экранированию базовых деталей.
Нет необходимости вызывать базовый интерфейс при запуске, что улучшает совместимость и надежность.
*/
var Connect=function(streamStore,isUserMedia){
	var bufferSize=streamStore.BufferSize||Recorder.BufferSize;
	
	var ctx=Recorder.Ctx,stream=streamStore.Stream;
	var mediaConn=function(node){
		var media=stream._m=ctx.createMediaStreamSource(stream);
		var ctxDest=ctx.destination,cmsdTxt="createMediaStreamDestination";
		if(ctx[cmsdTxt]){
			ctxDest=ctx[cmsdTxt]();
		};
		media.connect(node);
		node.connect(ctxDest);
	}
	var isWebM,isWorklet,badInt,webMTips="";
	var calls=stream._call;
	
	// Обработка аудиоданных, отправленных браузером
	var onReceive=function(float32Arr){
		for(var k0 in calls){//has item
			var size=float32Arr.length;
			
			var pcm=new Int16Array(size);
			var sum=0;
			for(var j=0;j<size;j++){//floatTo16BitPCM 
				var s=Math.max(-1,Math.min(1,float32Arr[j]));
				s=s<0?s*0x8000:s*0x7FFF;
				pcm[j]=s;
				sum+=Math.abs(s);
			};
			
			for(var k in calls){
				calls[k](pcm,sum);
			};
			
			return;
		};
	};
	
	var scriptProcessor="ScriptProcessor";//一 Занести в стек имена строк, что хорошо для сжатия js
	var audioWorklet="audioWorklet";
	var recAudioWorklet=RecTxt+" "+audioWorklet;
	var RecProc="RecProc";
	var MediaRecorderTxt="MediaRecorder";
	var MRWebMPCM=MediaRecorderTxt+".WebM.PCM";


//===================Третий способ подключения=========================
	//Обработка Antique ScriptProcessor, в настоящее время совместимая со всеми браузерами, хотя это устаревший метод, он более надежен и имеет лучшую производительность на мобильных устройствах, чем AudioWorklet.
	var oldFn=ctx.createScriptProcessor||ctx.createJavaScriptNode;
	var oldIsBest="Поскольку " + audioWorklet + " имеет 375 обратных вызовов в секунду, могут возникнуть проблемы с производительностью на мобильных устройствах, что приведет к потере обратных вызовов и более коротким записям. На ПК это не повлияет, поэтому на данный момент не рекомендуется включать " + audioWorklet;
	var oldScript=function(){
		isWorklet=stream.isWorklet=false;
		_Disconn_n(stream);
		CLog("Connect использует старый "+scriptProcessor+"，"+(Recorder[ConnectEnableWorklet]?"Но уже":"Может") + "настраивать"+RecTxt+"."+ConnectEnableWorklet+"=true Попробуйте включить"+audioWorklet+webMTips+oldIsBest,3);
		
		var process=stream._p=oldFn.call(ctx,bufferSize,1,1);//Один канал, экономит сложную обработку данных
		mediaConn(process);
		
		var _DsetTxt="_D220626",_Dset=Recorder[_DsetTxt];if(_Dset)CLog("Use "+RecTxt+"."+_DsetTxt,3);
		process.onaudioprocess=function(e){
			var arr=e.inputBuffer.getChannelData(0);
			if(_Dset){//Параметры для временной отладки, будут удалены в будущем.
				arr=new Float32Array(arr);//Блоки являются общими и должны быть скопированы.
				setTimeout(function(){ onReceive(arr) });//Немедленно выйдите из обратного вызова, чтобы попытаться уменьшить влияние на запись браузера
			}else{
				onReceive(arr);
			};
		};
	};


//===================Способ подключения 2=========================
var connWorklet=function(){
	//Попробуйте включить обработку AudioWorklet
	isWebM=stream.isWebM=false;
	_Disconn_r(stream);
	
	isWorklet=stream.isWorklet=!oldFn || Recorder[ConnectEnableWorklet];
	var AwNode=window.AudioWorkletNode;
	if(!(isWorklet && ctx[audioWorklet] && AwNode)){
		oldScript();//Отключено или не поддерживается, используйте старую версию напрямую
		return;
	};
	var clazzUrl=function(){
		var xf=function(f){return f.toString().replace(/^function|DEL_/g,"").replace(/\$RA/g,recAudioWorklet)};
		var clazz='class '+RecProc+' extends AudioWorkletProcessor{';
			clazz+="constructor "+xf(function(option){
				DEL_super(option);
				var This=this,bufferSize=option.processorOptions.bufferSize;
				This.bufferSize=bufferSize;
				This.buffer=new Float32Array(bufferSize*2);// Если буфер переполнится
				This.pos=0;
				This.port.onmessage=function(e){
					if(e.data.kill){
						console.log("$RA kill call");
					}
				};
				console.log("$RA .ctor call", option);
			});
			
			//https://developer.mozilla.org/en-US/docs/Web/API/AudioWorkletProcessor/process
			// Каждый обратный вызов получает 128 выборок данных, 375 обратных вызовов в секунду.
			// Высокая частота приводит к проблемам производительности на мобильной стороне.
			// В результате количество обратных вызовов недостаточно, что приводит к потере данных.
			// На стороне ПК, похоже, нет проблем с производительностью
			clazz+="process "+xf(function(input,b,c){//Hужно дождаться активации ctx, прежде чем будет обратный вызов.
				var This=this,bufferSize=This.bufferSize;
				var buffer=This.buffer,pos=This.pos;
				input=(input[0]||[])[0]||[];
				if(input.length){
					buffer.set(input,pos);
					pos+=input.length;
					
					var len=~~(pos/bufferSize)*bufferSize;
					if(len){
						this.port.postMessage({ val: buffer.slice(0,len) });
						
						var more=buffer.subarray(len,pos);
						buffer=new Float32Array(bufferSize*2);
						buffer.set(more);
						pos=more.length;
						This.buffer=buffer;
					}
					This.pos=pos;
				}
				return !This.kill;
			});
		clazz+='}'
			+'try{'
				+'registerProcessor("'+RecProc+'", '+RecProc+')'
			+'}catch(e){'
				+'console.error("'+recAudioWorklet+'Регистрация не удалась",e)'
			+'}';
		//URL.createObjectURL Некоторые локальные браузеры выдадут сообщение
		// «Не разрешено загружать локальный ресурс, используйте dataurl напрямую».
		return "data:text/javascript;base64,"+btoa(unescape(encodeURIComponent(clazz)));
	};
	
	var awNext=function(){//Можно продолжать, без отключения вызова
		return isWorklet && stream._na;
	};
	var nodeAlive=stream._na=function(){
		//Он будет вызван при запуске. Если данные не получены, определяется, что возникла проблема с AudioWorklet, и старый будет восстановлен.
		if(badInt!==""){//Нет данных обратного вызова
			clearTimeout(badInt);
			badInt=setTimeout(function(){
				badInt=0;
				if(awNext()){
					CLog(audioWorklet+"Звук не вернулся, возобновите использование"+scriptProcessor,3);
					oldFn&&oldScript();//Возможно, в будущем это будет отключено
				};
			},500);
		};
	};
	var createNode=function(){
		if(!awNext())return;
		var node=stream._n=new AwNode(ctx, RecProc, {
			processorOptions:{bufferSize:bufferSize}
		});
		mediaConn(node);
		node.port.onmessage=function(e){
			if(badInt){
				clearTimeout(badInt);badInt="";
			};
			if(awNext()){
				onReceive(e.data.val);
			}else if(!isWorklet){
				CLog(audioWorklet+"Избыточные обратные вызовы",3);
			};
		};
		CLog("Connect использует "+audioWorklet+"，настраивает "+RecTxt+"."+ConnectEnableWorklet+"=false Восстановить старый стиль "+scriptProcessor+webMTips+oldIsBest,3);
	};
	
	//Если возобновление работы с начала и построение следующего узла выполняются одновременно, некоторые браузеры могут выйти из строя. Вы можете протестировать его в ztest_chrome_bug_AudioWorkletNode.html в исходном коде. Поэтому поместите весь код в resume (независимо от catch), чтобы избежать этой проблемы.
	ctx.resume()[calls&&"finally"](function(){//Закомментируйте эту строку и наблюдайте, как ваш браузер зависнет: STATUS_ACCESS_VIOLATION
		if(!awNext())return;
		if(ctx[RecProc]){
			createNode();
			return;
		};
		var url=clazzUrl();
		ctx[audioWorklet].addModule(url).then(function(e){
			if(!awNext())return;
			ctx[RecProc]=1;
			createNode();
			if(badInt){//Повторное определение времени
				nodeAlive();
			};
		})[CatchTxt](function(e){ //fix Ключевое слово, гарантирующее, что catch останется в строковом формате при сжатии
			CLog(audioWorklet+".addModule fail",1,e);
			awNext()&&oldScript();
		});
	});
};


//===================Способ подключения #1 =========================
var connWebM=function(){
	//Oткрыть MediaRecorder для записи обработки webm+pcm
	var MR=window[MediaRecorderTxt];
	var onData="ondataavailable";
	var webmType="audio/webm; codecs=pcm";
	isWebM=stream.isWebM=Recorder[ConnectEnableWebM];
	
	var supportMR=MR && (onData in MR.prototype) && MR.isTypeSupported(webmType);
	webMTips=supportMR?"":"（此浏览器不支持"+MRWebMPCM+"）";
	if(!isUserMedia || !isWebM || !supportMR){
		connWorklet(); //Запись без микрофона (частота дискретизации MediaRecorder не контролируется) или отключена, или MediaRecorder не поддерживается, или webm+pcm не поддерживается
		return;
	}
	
	var mrNext=function(){//Можно продолжать, без отключения вызова
		return isWebM && stream._ra;
	};
	var mrAlive=stream._ra=function(){
		//startОн будет вызван при отсутствии полученных данных. Если данные не получены, определяется, что возникла проблема с MediaRecorder, и выполняется процесс понижения версии
		if(badInt!==""){//Нет данных обратного вызова
			clearTimeout(badInt);
			badInt=setTimeout(function(){
				//badInt=0; Зарезервировано для nodeAlive для продолжения оценки
				if(mrNext()){
					CLog(MediaRecorderTxt+"Звук не возвращается, понизьте до"+audioWorklet,3);
					connWorklet();
				};
			},500);
		};
	};
	
	var mrSet=Object.assign({mimeType:webmType}, Recorder.ConnectWebMOptions);
	var mr=stream._r=new MR(stream, mrSet);
	var webmData=stream._rd={sampleRate:ctx[sampleRateTxt]};
	mr[onData]=function(e){
		//Извлечение данных PCM из WebM. Если извлечение не удалось, дождитесь тайм-аута badInt и понизьте уровень обработки
		var reader=new FileReader();
		reader.onloadend=function(){
			if(mrNext()){
				var f32arr=WebM_Extract(new Uint8Array(reader.result),webmData);
				if(!f32arr)return;
				if(f32arr==-1){//Невозможно извлечь, надо понизить версию
					connWorklet();
					return;
				};
				
				if(badInt){
					clearTimeout(badInt);badInt="";
				};
				onReceive(f32arr);
			}else if(!isWebM){
				CLog(MediaRecorderTxt+"Избыточные обратные вызовы",3);
			};
		};
		reader.readAsArrayBuffer(e.data);
	};
	mr.start(~~(bufferSize/48));//Интервал обратного вызова 48k
	CLog("Надо использовать Connect"+MRWebMPCM+"，настроить"+RecTxt+"."+ConnectEnableWebM+"=false Извлекаемый"+audioWorklet+"или старомодный"+scriptProcessor);
};

	connWebM();
};
var ConnAlive=function(stream){
	if(stream._na) stream._na(); //Проверьте, является ли соединение  AudioWorklet действительным, если нет, вернитесь к старому ScriptProcessor
	if(stream._ra) stream._ra(); //Проверьте, является ли подключение MediaRecorder допустимым, если нет, понизьте версию
};
var _Disconn_n=function(stream){
	stream._na=null;
	if(stream._n){
		stream._n.port.postMessage({kill:true});
		stream._n.disconnect();
		stream._n=null;
	};
};
var _Disconn_r=function(stream){
	stream._ra=null;
	if(stream._r){
		stream._r.stop();
		stream._r=null;
	};
};
var Disconnect=function(streamStore){
	streamStore=streamStore||Recorder;
	var isGlobal=streamStore==Recorder;
	
	var stream=streamStore.Stream;
	if(stream){
		if(stream._m){
			stream._m.disconnect();
			stream._m=null;
		};
		if(stream._p){
			stream._p.disconnect();
			stream._p.onaudioprocess=stream._p=null;
		};
		_Disconn_n(stream);
		_Disconn_r(stream);
		
		if(isGlobal){//При глобальном отключении потока (микрофона) и не обработке напрямую предоставленного потока.
			var tracks=stream.getTracks&&stream.getTracks()||stream.audioTracks||[];
			for(var i=0;i<tracks.length;i++){
				var track=tracks[i];
				track.stop&&track.stop();
			};
			stream.stop&&stream.stop();
		};
	};
	streamStore.Stream=0;
};

/*
    Преобразовать частоту дискретизации данных PCM pcmDatas: [[Int16,...]]
    список фрагментов PCM
    pcmSampleRate:48000
    Частота дискретизации данных PCM
    newSampleRate:16000
    Частота дискретизации для преобразования.
    Если newSampleRate>=pcmSampleRate, обработка выполняться не будет.
    Если значение меньше, будет выполнена повторная выборка.
    prevChunkInfo:{}
    Необязательно, возвращаемое значение последнего вызова, используется для непрерывного преобразования.
    Обработка этого вызова начнется с последней конечной позиции.
    Или вы можете определить ChunkInfo, чтобы начать преобразование с позиции,
    указанной параметром pcmDatas:
        { Необязательно, элемент конфигурации
            frameSize:123456 Размер кадра,
            количество PCM Int16 на кадр,
            длина PCM после преобразования частоты дискретизации является целым числом,
            кратным frameSize, используется для непрерывного преобразования.
            В настоящее время он полезен только в формате mp3.
            Значение frameSize равно 1152, поэтому длительность кодированного mp3-файла точно такая же,
            как длительность PCM-файла.
            В противном случае длительность mp3-файла будет больше,
            поскольку дополнительные данные добавляются, когда последний кадр mp3-записи не заполнен. frameType:""
            Тип кадра, обычно rec.set.type.
            Если указан этот параметр, указывать frameSize не требуется.
            Для назначения frameSize будет автоматически использовано лучшее значение.
            В настоящее время поддерживается только mp3=1152 (количество выборок на кадр MPEG1 Layer3),
            а другие типы=1.
            Два вышеуказанных параметра используются для непрерывного преобразования.
            Максимум можно использовать один.
            Если не указано иное, специальная обработка кадров производиться не будет.
            Если указано, prevChunkInfo должно быть указано одновременно,
            чтобы быть эффективным. Последний бит данных обрабатывается без указания размера кадра
            для вывода последнего бита остаточных данных. }

    Return ChunkInfo:
        { //Определяемо, преобразовать из указанной позиции в конечную
            index:0 pcmDatas обработал индекс
            offset:0.0
            Следующая позиция смещения в pcm, соответствующая обработанному индексу
            //Только как возвращаемое значение frameNext:null||[Int16,...]
            Частичные данные следующего кадра, возможно только при установленном
            frameSize sampleRate:16000
            Частота дискретизации результата, <=newSampleRate data:[Int16,...]
            Преобразованный результат PCM;
            если это непрерывное преобразование и в pcmDatas нет новых данных,
            длина данных может быть 0 }
*/
Recorder.SampleData=function(pcmDatas,pcmSampleRate,newSampleRate,prevChunkInfo,option){
	prevChunkInfo||(prevChunkInfo={});
	var index=prevChunkInfo.index||0;
	var offset=prevChunkInfo.offset||0;
	
	var frameNext=prevChunkInfo.frameNext||[];
	option||(option={});
	var frameSize=option.frameSize||1;
	if(option.frameType){
		frameSize=option.frameType=="mp3"?1152:1;
	};
	
	var nLen=pcmDatas.length;
	if(index>nLen+1){
		CLog("SampleData: Кажется, что вход не сброшен. chunk "+index+">"+nLen,3);
	};
	var size=0;
	for(var i=index;i<nLen;i++){
		size+=pcmDatas[i].length;
	};
	size=Math.max(0,size-Math.floor(offset));
	
	//выборка https://www.cnblogs.com/blqw/p/3782420.html
	var step=pcmSampleRate/newSampleRate;
	if(step>1){//新采样低于录音采样，进行抽样
		size=Math.floor(size/step);
	}else{//新采样高于录音采样不处理，省去了插值处理
		step=1;
		newSampleRate=pcmSampleRate;
	};
	
	size+=frameNext.length;
	var res=new Int16Array(size);
	var idx=0;
	//添加上一次不够一帧的剩余数据
	for(var i=0;i<frameNext.length;i++){
		res[idx]=frameNext[i];
		idx++;
	};
	//处理数据
	for (;index<nLen;index++) {
		var o=pcmDatas[index];
		var i=offset,il=o.length;
		while(i<il){
			//res[idx]=o[Math.round(i)]; 直接简单抽样
			
			//https://www.cnblogs.com/xiaoqi/p/6993912.html
			//当前点=当前点+到后面一个点之间的增量，音质比直接简单抽样好些
			var before = Math.floor(i);
			var after = Math.ceil(i);
			var atPoint = i - before;
			
			var beforeVal=o[before];
			var afterVal=after<il ? o[after]
				: (//后个点越界了，查找下一个数组
					(pcmDatas[index+1]||[beforeVal])[0]||0
				);
			res[idx]=beforeVal+(afterVal-beforeVal)*atPoint;
			
			idx++;
			i+=step;//抽样
		};
		offset=i-il;
	};
	//帧处理
	frameNext=null;
	var frameNextSize=res.length%frameSize;
	if(frameNextSize>0){
		var u8Pos=(res.length-frameNextSize)*2;
		frameNext=new Int16Array(res.buffer.slice(u8Pos));
		res=new Int16Array(res.buffer.slice(0,u8Pos));
	};
	
	return {
		index:index
		,offset:offset
		
		,frameNext:frameNext
		,sampleRate:newSampleRate
		,data:res
	};
};


/*计算音量百分比的一个方法
pcmAbsSum: pcm Int16所有采样的绝对值的和
pcmLength: pcm长度
返回值：0-100，主要当做百分比用
注意：这个不是分贝，因此没用volume当做名称*/
Recorder.PowerLevel=function(pcmAbsSum,pcmLength){
	/*计算音量 https://blog.csdn.net/jody1989/article/details/73480259
	更高灵敏度算法:
		限定最大感应值10000
			线性曲线：低音量不友好
				power/10000*100 
			对数曲线：低音量友好，但需限定最低感应值
				(1+Math.log10(power/10000))*100
	*/
	var power=(pcmAbsSum/pcmLength) || 0;//NaN
	var level;
	if(power<1251){//1250的结果10%，更小的音量采用线性取值
		level=Math.round(power/1250*10);
	}else{
		level=Math.round(Math.min(100,Math.max(0,(1+Math.log(power/10000)/Math.log(10))*100)));
	};
	return level;
};

/*计算音量，单位dBFS（满刻度相对电平）
maxSample: 为16位pcm采样的绝对值中最大的一个（计算峰值音量），或者为pcm中所有采样的绝对值的平局值
返回值：-100~0 （最大值0dB，最小值-100代替-∞）
*/
Recorder.PowerDBFS=function(maxSample){
	var val=Math.max(0.1, maxSample||0),Pref=0x7FFF;
	val=Math.min(val,Pref);
	//https://www.logiclocmusic.com/can-you-tell-the-decibel/
	//https://blog.csdn.net/qq_17256689/article/details/120442510
	val=20*Math.log(val/Pref)/Math.log(10);
	return Math.max(-100,Math.round(val));
};




//Вывод журнала со временем, можно задать пустую функцию, чтобы заблокировать вывод журнала
//CLog(msg,errOrLogMsg, logMsg...)
// Если err — это число, оно представляет тип журнала
//      1: error
//      2: log default
//      3: warn,
//      в противном случае он рассматривается как вывод содержимого.
// Первый параметр не может быть объектом, поскольку его необходимо объединить со временем.
// За ним может следовать неограниченное количество выходных параметров.
Recorder.CLog=function(msg,err){
	var now=new Date();
	var t=("0"+now.getMinutes()).substr(-2)
		+":"+("0"+now.getSeconds()).substr(-2)
		+"."+("00"+now.getMilliseconds()).substr(-3);
	var recID=this&&this.envIn&&this.envCheck&&this.id;
	var arr=["["+t+" "+RecTxt+(recID?":"+recID:"")+"]"+msg];
	var a=arguments,console=window.console||{};
	var i=2,fn=console.log;
	if(typeof(err)=="number"){
		fn=err==1?console.error:err==3?console.warn:fn;
	}else{
		i=1;
	};
	for(;i<a.length;i++){
		arr.push(a[i]);
	};
	if(IsLoser){//Антикварный браузер, гарантируется только базовый исполняемый код без исключений
		fn&&fn("[IsLoser]"+arr[0],arr.length>1?arr:"");
	}else{
		fn.apply(console,arr);
	};
};
var CLog=function(){ Recorder.CLog.apply(this,arguments); };
var IsLoser=true;try{IsLoser=!console.log.apply;}catch(e){};




var ID=0;
function initFn(set){
	this.id=++ID;
	
	//Если включена статистика трафика, запрос изображения будет отправлен сюда
	Traffic();
	
	
	var o={
		type:"mp3" //Тип выходного файла: mp3, wav. Размер выходного файла WAV слишком большой и не рекомендуется. Однако поддержка кодирования mp3 приведет к тому, что файл js будет слишком большим. Если поддержка mp3 не требуется, файл js можно значительно сократить.
		,bitRate:16 //Битрейт wav: 16 или 8 бит, MP3: 8kbps 1k/s, 8kbps 2k/s Файл записи очень маленький
		
		,sampleRate:16000 //Частота дискретизации, размер формата wav = sampleRate * time; mp3 этот пункт оказывает влияние на низкие битрейты и почти не влияет на высокие битрейты.
					//wav любое значение, mp3 диапазон значений：48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000
					//Частота дискретизации https://www.cnblogs.com/devin87/p/mp3-recorder.html
		
		,onProcess:NOOP //fn(buffers,powerLevel,bufferDuration,bufferSampleRate,newBufferIdx,asyncEnd) buffers=[[Int16,...],...]：Буферизованные данные PCM представляют собой все клипы PCM с начала записи до настоящего момента; powerLevel: текущий уровень громкости буферизации 0-100, bufferDuration: длительность буферизации, bufferSampleRate: частота дискретизации, используемая буфером (если тип поддерживает перекодирование во время записи (Worker), эта частота дискретизации совпадает с установленной частотой дискретизации, в противном случае она может отличаться); newBufferIdx: начальный индекс буфера, добавленный в этом обратном вызове; asyncEnd:fn() Если onProcess асинхронный (возвращаемое значение равно true), этот обратный вызов необходимо вызвать после завершения обработки. Если он не асинхронный, проигнорируйте этот параметр. Этот метод обратного вызова должен быть по-настоящему асинхронным (если он не может быть по-настоящему асинхронным, его необходимо обернуть в setTimeout). Возвращаемое значение onProcess: Если возвращается значение true, это означает, что асинхронный режим включен. Асинхронность необходима в некоторых ситуациях, когда требуется выполнять большие объемы вычислений. asyncEnd необходимо вызывать после завершения асинхронной обработки (setTimeout необходимо использовать, если настоящая асинхронность невозможна). После выполнения onProcess все вновь добавленные буферы будут заменены пустыми массивами. Поэтому в начале этого обратного вызова все буферы от newBufferIdx до конца этого обратного вызова должны быть немедленно сохранены в другом массиве и записаны обратно в конец этого обратного вызова в буферах после обработки.
		
		//*******Расширенные настройки******
		//,sourceStream:MediaStream Object
//Опционально предоставить медиапоток напрямую, записывать и обрабатывать аудиоданные в реальном времени из этого потока (текущий экземпляр Recorder имеет этот поток исключительно); если он не указан, это обычная запись с микрофона, а getUserMedia предоставляет аудиопоток (все экземпляры Recorder используют один и тот же поток)
//Например: поток, возвращаемый методом captureStream аудио- и видеотеговых узлов DOM (экспериментальная функция, не очень хорошо поддерживаемая различными браузерами); удаленная трансляция в WebRTC; самостоятельно созданный поток и т. д.
//Примечание: в потоке должна быть хотя бы одна звуковая дорожка (Audio Track). Например, аудиотег должен дождаться начала воспроизведения, прежде чем появится звуковая дорожка, в противном случае открытие не удастся.
		
		//,audioTrackSet:{ deviceId:"",groupId:"", autoGainControl:true, echoCancellation:true, noiseSuppression:true }
				//Параметры конфигурации звука метода getUserMedia при записи с помощью обычного микрофона, такие как указание идентификатора устройства, переключатели эхоподавления и шумоподавления; Примечание: любые предоставленные значения конфигурации не обязательно вступят в силу.
				//Поскольку микрофон используется глобально, вам необходимо закрыть предыдущий и открыть его снова после новой настройки.
				//Больше ссылок: https://developer.mozilla.org/en-US/docs/Web/API/MediaTrackConstraints
		
		//,disableEnvInFix:false Внутренний параметр, отключает компенсацию потери входного аудиосигнала при зависании устройства
		
		//,takeoffEncodeChunk:NOOP //fn(chunkBytes) chunkBytes=[Uint8,...]：Перехватите выходные данные кодировщика в среде кодирования в реальном времени. Когда кодер кодирует действительные двоичные аудиоданные в реальном времени, этот метод вызывается обратно в реальном времени. Параметр представляет собой двоичный массив Uint8Array, представляющий собой закодированный фрагмент аудиоданных. Все фрагменты байтов объединяются в единое целое. Идея данной реализации была первоначально предложена QQ2543775048.
		//Когда предоставляется этот метод обратного вызова, вывод данных кодировщика будет взят под контроль, и кодировщик прекратит сохранять сгенерированные аудиоданные; требования к среде относительно высоки: если текущая среда не поддерживает обработку кодирования в реальном времени, при открытии будет напрямую использована логика отказа.
		//Поэтому вызов метода stop после предоставления этого обратного вызова не позволит получить действительные аудиоданные, поскольку в кодере нет аудиоданных, поэтому возвращаемый при остановке двоичный объект будет двоичным объектом с длиной байта 0.
		//В настоящее время только формат mp3 реализует кодирование в реальном времени. В среде, поддерживающей обработку в реальном времени, закодированные фрагменты mp3 будут вызываться обратно в реальном времени с помощью этого метода, и все фрагменты будут объединены вместе для формирования полного mp3. Результат такого склеивания лучше, чем качество звука, сгенерированного в реальном времени методом имитации, поскольку тишина в начале и конце естественным образом исключается.
		//В настоящее время этот обратный вызов не может быть предоставлен для форматов, отличных от mp3, и при открытии будет напрямую использоваться логика отказа.

	};
	
	for(var k in set){
		o[k]=set[k];
	};
	this.set=o;
	
	this._S=9;//остановить блокировку синхронизации, остановить может предотвратить запуск, который еще не был запущен во время открытого процесса
	this.Sync={O:9,C:9};//То же, что и Recorder.Sync, за исключением того, что он не является глобальным и используется только для упрощения логики кода и не имеет практического эффекта.
};
//Синхронная блокировка, контролирует конкуренцию за Stream; используется для прерывания асинхронного открытия при закрытии; если открытый объект изменяется, закрытие блокируется и управление потоком передается новому объекту
Recorder.Sync={/*open*/O:9,/*close*/C:9};

Recorder.prototype=initFn.prototype={
	CLog:CLog
	
	//В каком объекте хранятся данные, связанные с потоком? Если указан sourceStream, данные сохраняются непосредственно в текущем объекте, в противном случае они сохраняются глобально.
	,_streamStore:function(){
		if(this.set.sourceStream){
			return this;
		}else{
			return Recorder;
		}
	}
	
	//Открыть ресурс записи True(), False(msg, isUserNotAllow), необходимо вызвать close. Примечание: этот метод является асинхронным; его обычно открывают во время использования и закрывают сразу после использования; его можно вызывать многократно и использовать для проверки возможности записи
	,open:function(True,False){
		var This=this,streamStore=This._streamStore();
		True=True||NOOP;
		var failCall=function(errMsg,isUserNotAllow){
			isUserNotAllow=!!isUserNotAllow;
			This.CLog("Запись не открылась："+errMsg+",isUserNotAllow:"+isUserNotAllow,1);
			False&&False(errMsg,isUserNotAllow);
		};
		
		var ok=function(){
			This.CLog("open ok id:"+This.id);
			True();
			
			This._SO=0;//Разблокировать остановку от вызова начать в открытом
		};
		
		
		//Синхронная блокировка
		var Lock=streamStore.Sync;
		var lockOpen=++Lock.O,lockClose=Lock.C;
		This._O=This._O_=lockOpen;//Запоминаем текущее открытие и не допускаем закрытия, если оно изменится. Это предполагает, что новый объект заменил текущий объект и больше не используется.
		This._SO=This._S;//Помните об остановке в открытом процессе. Любой сигнал об остановке в середине не может продолжить старт в открытом поле.
		var lockFail=function(){
			//Разрешено многократное открытие, но закрытие запрещено, или функция закрытия уже была вызвана.
			if(lockClose!=Lock.C || !This._O){
				var err="open Отменено";
				if(lockOpen==Lock.O){
					//Новых открытий нет, а закрытие было отменено. Последнее закрытие должно быть выполнено здесь.
					This.close();
				}else{
					err="open прервано";
				};
				failCall(err);
				return true;
			};
		};
		
		//Проверка конфигурации среды
		var checkMsg=This.envCheck({envName:"H5",canProcess:true});
		if(checkMsg){
			failCall("Невозможно записать："+checkMsg);
			return;
		};
		
		
		//***********Аудиопоток предоставляется напрямую************
		if(This.set.sourceStream){
			if(!Recorder.GetContext()){
				failCall("Этот браузер не поддерживает получение записей из потока");
				return;
			};
			
			Disconnect(streamStore);//Возможно, его открыли. Попробуйте сначала отключить его
			This.Stream=This.set.sourceStream;
			This.Stream._call={};
			
			try{
				Connect(streamStore);
			}catch(e){
				failCall("Не удалось открыть запись из потока："+e.message);
				return;
			}
			ok();
			return;
		};
		
		
		//***********Откройте микрофон, чтобы получить глобальный аудиопоток************
		var codeFail=function(code,msg){
			try{//Приоритет кросс-доменного обнаружения
				window.top.a;
			}catch(e){
				failCall('Нет разрешения на запись (кросс-доменный, попробуйте добавить политику доступа к микрофону в iframe, например allow="camera;microphone")');
				return;
			};
			
			if(/Permission|Allow/i.test(code)){
				failCall("Пользователь отклонил разрешение на запись",true);
			}else if(window.isSecureContext===false){
				failCall("Браузер запрещает запись небезопасных страниц, решить эту проблему можно включив https");
			}else if(/Found/i.test(code)){//Возможно, оборудование отсутствует из-за небезопасной среды.
				failCall(msg+"，Микрофон недоступен.");
			}else{
				failCall(msg);
			};
		};
		
		
		//Если он уже открыт и работает, не открывайте его снова.
		if(Recorder.IsOpen()){
			ok();
			return;
		};
		if(!Recorder.Support()){
			codeFail("","Этот браузер не поддерживает запись");
			return;
		};
				
		//Запросить разрешение. Если вы никогда не авторизовали его, браузер, как правило, выведет диалоговое окно с запросом разрешения.
		var f1=function(stream){
			//https://github.com/xiangyuecn/Recorder/issues/14 获取到的track.readyState!="live"，Это может быть нормально, когда он просто перезванивает, но через некоторое время он может отключиться по неизвестным причинам. Задержка обеспечивает настоящую асинхронность. Не влияет на обычные браузеры.
			setTimeout(function(){
				stream._call={};
				var oldStream=Recorder.Stream;
				if(oldStream){
					Disconnect(); //Непосредственно отключите существующее соединение, старое соединение будет автоматически разорвано, если оно не будет завершено.
					stream._call=oldStream._call;
				};
				Recorder.Stream=stream;
				if(lockFail())return;
				
				if(Recorder.IsOpen()){
					if(oldStream)This.CLog("Было обнаружено, что open вызывался несколько раз одновременно",1);
					
					Connect(streamStore,1);
					ok();
				}else{
					failCall("Запись отключена: нет аудиопотока");
				};
			},100);
		};
		var f2=function(e){
			var code=e.name||e.message||e.code+":"+e;
			This.CLog("Ошибка при запросе разрешения на запись",1,e);
			
			codeFail(code,"Невозможно записать："+code);
		};
		
		var trackSet={
			noiseSuppression:false //默认禁用降噪，原声录制，免得移动端表现怪异（包括系统播放声音变小）
			,echoCancellation:false //回声消除
		};
		var trackSet2=This.set.audioTrackSet;
		for(var k in trackSet2)trackSet[k]=trackSet2[k];
		trackSet.sampleRate=Recorder.Ctx.sampleRate;//必须指明采样率，不然手机上MediaRecorder采样率16k
		
		try{
			var pro=Recorder.Scope[getUserMediaTxt]({audio:trackSet},f1,f2);
		}catch(e){//不能设置trackSet就算了
			This.CLog(getUserMediaTxt,3,e);
			pro=Recorder.Scope[getUserMediaTxt]({audio:true},f1,f2);
		};
		if(pro&&pro.then){
			pro.then(f1)[CatchTxt](f2); //fix 关键字，保证catch压缩时保持字符串形式
		};
	}
	//关闭释放录音资源
	,close:function(call){
		call=call||NOOP;
		
		var This=this,streamStore=This._streamStore();
		This._stop();
		
		var Lock=streamStore.Sync;
		This._O=0;
		if(This._O_!=Lock.O){
			//唯一资源Stream的控制权已交给新对象，这里不能关闭。此处在每次都弹权限的浏览器内可能存在泄漏，新对象被拒绝权限可能不会调用close，忽略这种不处理
			This.CLog("close被忽略（因为同时open了多个rec，只有最后一个会真正close）",3);
			call();
			return;
		};
		Lock.C++;//获得控制权
		
		Disconnect(streamStore);
		
		This.CLog("close");
		call();
	}
	
	
	
	
	
	/*模拟一段录音数据，后面可以调用stop进行编码，需提供pcm数据[1,2,3...]，pcm的采样率*/
	,mock:function(pcmData,pcmSampleRate){
		var This=this;
		This._stop();//清理掉已有的资源
		
		This.isMock=1;
		This.mockEnvInfo=null;
		This.buffers=[pcmData];
		This.recSize=pcmData.length;
		This[srcSampleRateTxt]=pcmSampleRate;
		return This;
	}
	,envCheck:function(envInfo){//平台环境下的可用性检查，任何时候都可以调用检查，返回errMsg:""正常，"失败原因"
		//envInfo={envName:"H5",canProcess:true}
		var errMsg,This=this,set=This.set;
		
		//检测CPU的数字字节序，TypedArray字节序是个迷，直接拒绝罕见的大端模式，因为找不到这种CPU进行测试
		var tag="CPU_BE";
		if(!errMsg && !Recorder[tag] && window.Int8Array && !new Int8Array(new Int32Array([1]).buffer)[0]){
			Traffic(tag); //如果开启了流量统计，这里将发送一个图片请求
			errMsg="不支持"+tag+"架构";
		};
		
		//编码器检查环境下配置是否可用
		if(!errMsg){
			var type=set.type;
			if(This[type+"_envCheck"]){//编码器已实现环境检查
				errMsg=This[type+"_envCheck"](envInfo,set);
			}else{//未实现检查的手动检查配置是否有效
				if(set.takeoffEncodeChunk){
					errMsg=type+"类型"+(This[type]?"":"(未加载编码器)")+"不支持设置takeoffEncodeChunk";
				};
			};
		};
		
		return errMsg||"";
	}
	,envStart:function(mockEnvInfo,sampleRate){//平台环境相关的start调用
		var This=this,set=This.set;
		This.isMock=mockEnvInfo?1:0;//非H5环境需要启用mock，并提供envCheck需要的环境信息
		This.mockEnvInfo=mockEnvInfo;
		This.buffers=[];//数据缓冲
		This.recSize=0;//数据大小
		
		This.envInLast=0;//envIn接收到最后录音内容的时间
		This.envInFirst=0;//envIn接收到的首个录音内容的录制时间
		This.envInFix=0;//补偿的总时间
		This.envInFixTs=[];//补偿计数列表
		
		//engineCtx需要提前确定最终的采样率
		var setSr=set[sampleRateTxt];
		if(setSr>sampleRate){
			set[sampleRateTxt]=sampleRate;
		}else{ setSr=0 }
		This[srcSampleRateTxt]=sampleRate;
		This.CLog(srcSampleRateTxt+": "+sampleRate+" set."+sampleRateTxt+": "+set[sampleRateTxt]+(setSr?" 忽略"+setSr:""), setSr?3:0);
		
		This.engineCtx=0;
		//此类型有边录边转码(Worker)支持
		if(This[set.type+"_start"]){
			var engineCtx=This.engineCtx=This[set.type+"_start"](set);
			if(engineCtx){
				engineCtx.pcmDatas=[];
				engineCtx.pcmSize=0;
			};
		};
	}
	,envResume:function(){//和平台环境无关的恢复录音
		//重新开始计数
		this.envInFixTs=[];
	}
	,envIn:function(pcm,sum){//和平台环境无关的pcm[Int16]输入
		var This=this,set=This.set,engineCtx=This.engineCtx;
		var bufferSampleRate=This[srcSampleRateTxt];
		var size=pcm.length;
		var powerLevel=Recorder.PowerLevel(sum,size);
		
		var buffers=This.buffers;
		var bufferFirstIdx=buffers.length;//之前的buffer都是经过onProcess处理好的，不允许再修改
		buffers.push(pcm);
		
		//有engineCtx时会被覆盖，这里保存一份
		var buffersThis=buffers;
		var bufferFirstIdxThis=bufferFirstIdx;
		
		//卡顿丢失补偿：因为设备很卡的时候导致H5接收到的数据量不够造成播放时候变速，结果比实际的时长要短，此处保证了不会变短，但不能修复丢失的音频数据造成音质变差。当前算法采用输入时间侦测下一帧是否需要添加补偿帧，需要(6次输入||超过1秒)以上才会开始侦测，如果滑动窗口内丢失超过1/3就会进行补偿
		var now=Date.now();
		var pcmTime=Math.round(size/bufferSampleRate*1000);
		This.envInLast=now;
		if(This.buffers.length==1){//记下首个录音数据的录制时间
			This.envInFirst=now-pcmTime;
		};
		var envInFixTs=This.envInFixTs;
		envInFixTs.splice(0,0,{t:now,d:pcmTime});
		//保留3秒的计数滑动窗口，另外超过3秒的停顿不补偿
		var tsInStart=now,tsPcm=0;
		for(var i=0;i<envInFixTs.length;i++){
			var o=envInFixTs[i];
			if(now-o.t>3000){
				envInFixTs.length=i;
				break;
			};
			tsInStart=o.t;
			tsPcm+=o.d;
		};
		//达到需要的数据量，开始侦测是否需要补偿
		var tsInPrev=envInFixTs[1];
		var tsIn=now-tsInStart;
		var lost=tsIn-tsPcm;
		if( lost>tsIn/3 && (tsInPrev&&tsIn>1000 || envInFixTs.length>=6) ){
			//丢失过多，开始执行补偿
			var addTime=now-tsInPrev.t-pcmTime;//距离上次输入丢失这么多ms
			if(addTime>pcmTime/5){//丢失超过本帧的1/5
				var fixOpen=!set.disableEnvInFix;
				This.CLog("["+now+"]"+(fixOpen?"":"未")+"补偿"+addTime+"ms",3);
				This.envInFix+=addTime;
				
				//用静默进行补偿
				if(fixOpen){
					var addPcm=new Int16Array(addTime*bufferSampleRate/1000);
					size+=addPcm.length;
					buffers.push(addPcm);
				};
			};
		};
		
		
		var sizeOld=This.recSize,addSize=size;
		var bufferSize=sizeOld+addSize;
		This.recSize=bufferSize;//此值在onProcess后需要修正，可能新数据被修改
		
		
		//此类型有边录边转码(Worker)支持，开启实时转码
		if(engineCtx){
			//转换成set的采样率
			var chunkInfo=Recorder.SampleData(buffers,bufferSampleRate,set[sampleRateTxt],engineCtx.chunkInfo);
			engineCtx.chunkInfo=chunkInfo;
			
			sizeOld=engineCtx.pcmSize;
			addSize=chunkInfo.data.length;
			bufferSize=sizeOld+addSize;
			engineCtx.pcmSize=bufferSize;//此值在onProcess后需要修正，可能新数据被修改
			
			buffers=engineCtx.pcmDatas;
			bufferFirstIdx=buffers.length;
			buffers.push(chunkInfo.data);
			bufferSampleRate=chunkInfo[sampleRateTxt];
		};
		
		var duration=Math.round(bufferSize/bufferSampleRate*1000);
		var bufferNextIdx=buffers.length;
		var bufferNextIdxThis=buffersThis.length;
		
		//允许异步处理buffer数据
		var asyncEnd=function(){
			//重新计算size，异步的早已减去添加的，同步的需去掉本次添加的然后重新计算
			var num=asyncBegin?0:-addSize;
			var hasClear=buffers[0]==null;
			for(var i=bufferFirstIdx;i<bufferNextIdx;i++){
				var buffer=buffers[i];
				if(buffer==null){//已被主动释放内存，比如长时间实时传输录音时
					hasClear=1;
				}else{
					num+=buffer.length;
					
					//推入后台边录边转码
					if(engineCtx&&buffer.length){
						This[set.type+"_encode"](engineCtx,buffer);
					};
				};
			};
			
			//同步清理This.buffers，不管buffers到底清了多少个，buffersThis是使用不到的进行全清
			if(hasClear && engineCtx){
				var i=bufferFirstIdxThis;
				if(buffersThis[0]){
					i=0;
				};
				for(;i<bufferNextIdxThis;i++){
					buffersThis[i]=null;
				};
			};
			
			//统计修改后的size，如果异步发生clear要原样加回来，同步的无需操作
			if(hasClear){
				num=asyncBegin?addSize:0;
				
				buffers[0]=null;//彻底被清理
			};
			if(engineCtx){
				engineCtx.pcmSize+=num;
			}else{
				This.recSize+=num;
			};
		};
		//实时回调处理数据，允许修改或替换上次回调以来新增的数据 ，但是不允许修改已处理过的，不允许增删第一维数组 ，允许将第二维数组任意修改替换成空数组也可以
		var asyncBegin=0,procTxt="rec.set.onProcess";
		try{
			asyncBegin=set.onProcess(buffers,powerLevel,duration,bufferSampleRate,bufferFirstIdx,asyncEnd);
		}catch(e){
			//此错误显示不要用CLog，这样控制台内相同内容不会重复打印
			console.error(procTxt+"回调出错是不允许的，需保证不会抛异常",e);
		};
		
		var slowT=Date.now()-now;
		if(slowT>10 && This.envInFirst-now>1000){ //1秒后开始onProcess性能监测
			This.CLog(procTxt+"低性能，耗时"+slowT+"ms",3);
		};
		
		if(asyncBegin===true){
			//开启了异步模式，onProcess已接管buffers新数据，立即清空，避免出现未处理的数据
			var hasClear=0;
			for(var i=bufferFirstIdx;i<bufferNextIdx;i++){
				if(buffers[i]==null){//已被主动释放内存，比如长时间实时传输录音时 ，但又要开启异步模式，此种情况是非法的
					hasClear=1;
				}else{
					buffers[i]=new Int16Array(0);
				};
			};
			
			if(hasClear){
				This.CLog("未进入异步前不能清除buffers",3);
			}else{
				//还原size，异步结束后再统计仅修改后的size，如果发生clear要原样加回来
				if(engineCtx){
					engineCtx.pcmSize-=addSize;
				}else{
					This.recSize-=addSize;
				};
			};
		}else{
			asyncEnd();
		};
	}
	
	
	
	
	//开始录音，需先调用open；只要open成功时，调用此方法是安全的，如果未open强行调用导致的内部错误将不会有任何提示，stop时自然能得到错误
	,start:function(){
		var This=this,ctx=Recorder.Ctx;
		
		var isOpen=1;
		if(This.set.sourceStream){//直接提供了流，仅判断是否调用了open
			if(!This.Stream){
				isOpen=0;
			}
		}else if(!Recorder.IsOpen()){//监测全局麦克风是否打开并且有效
			isOpen=0;
		};
		if(!isOpen){
			This.CLog("未open",1);
			return;
		};
		This.CLog("Начать запись");
		
		This._stop();
		This.state=3;//0未录音 1录音中 2暂停 3等待ctx激活
		This.envStart(null, ctx[sampleRateTxt]);
		
		//检查open过程中stop是否已经调用过
		if(This._SO&&This._SO+1!=This._S){//上面调用过一次 _stop
			//open未完成就调用了stop，此种情况终止start。也应尽量避免出现此情况
			This.CLog("start被中断",3);
			return;
		};
		This._SO=0;
		
		var end=function(){
			if(This.state==3){
				This.state=1;
				This.resume();
			}
		};
		if(ctx.state=="suspended"){
			var tag="AudioContext resume: ";
			This.CLog(tag+"wait...");
			ctx.resume().then(function(){
				This.CLog(tag+ctx.state);
				end();
			})[CatchTxt](function(e){ //比较少见，可能对录音没有影响
				This.CLog(tag+ctx.state+" 可能无法录音："+e.message,1,e);
				end();
			});
		}else{
			end();
		};
	}
	/*暂停录音*/
	,pause:function(){
		var This=this;
		if(This.state){
			This.state=2;
			This.CLog("pause");
			delete This._streamStore().Stream._call[This.id];
		};
	}
	/*恢复录音*/
	,resume:function(){
		var This=this;
		if(This.state){
			This.state=1;
			This.CLog("resume");
			This.envResume();
			
			var stream=This._streamStore().Stream;
			stream._call[This.id]=function(pcm,sum){
				if(This.state==1){
					This.envIn(pcm,sum);
				};
			};
			ConnAlive(stream);//AudioWorklet只会在ctx激活后运行
		};
	}
	
	
	
	
	,_stop:function(keepEngine){
		var This=this,set=This.set;
		if(!This.isMock){
			This._S++;
		};
		if(This.state){
			This.pause();
			This.state=0;
		};
		if(!keepEngine && This[set.type+"_stop"]){
			This[set.type+"_stop"](This.engineCtx);
			This.engineCtx=0;
		};
	}
	/*
	结束录音并返回录音数据blob对象
		True(blob,duration) blob：录音数据audio/mp3|wav格式
							duration：录音时长，单位毫秒
		False(msg)
		autoClose:false 可选，是否自动调用close，默认为false
	*/
	,stop:function(True,False,autoClose){
		var This=this,set=This.set,t1;
		var envInMS=This.envInLast-This.envInFirst, envInLen=envInMS&&This.buffers.length; //可能未start
		This.CLog("stop 和start时差"+(envInMS?envInMS+"ms 补偿"+This.envInFix+"ms"+" envIn:"+envInLen+" fps:"+(envInLen/envInMS*1000).toFixed(1):"-"));
		
		var end=function(){
			This._stop();//彻底关掉engineCtx
			if(autoClose){
				This.close();
			};
		};
		var err=function(msg){
			This.CLog("Не удалось завершить запись："+msg,1);
			False&&False(msg);
			end();
		};
		var ok=function(blob,duration){
			This.CLog("Конец записи"+(Date.now()-t1)+"ms Длительность аудио "+duration+"ms Размер файла"+blob.size+"b");
			if(set.takeoffEncodeChunk){//Принимает на себя вывод, а длина блоба равна 0
				This.CLog("После включения takeoffEncodeChunk длина блоба, возвращаемого stop, равна 0, и аудиоданные не предоставляются.",3);
			}else if(blob.size<Math.max(100,duration/2)){//1秒小于0.5k？
				err("Сгенерировано "+set.type+" невернo");
				return;
			};
			True&&True(blob,duration);
			end();
		};
		if(!This.isMock){
			var isCtxWait=This.state==3;
			if(!This.state || isCtxWait){
				err("Запись не началась"+(isCtxWait?"，AudioContext не запущен, поскольку перед началом записи не было взаимодействия с пользователем.":""));
				return;
			};
			This._stop(true);
		};
		var size=This.recSize;
		if(!size){
			err("Записи не были собраны");
			return;
		};
		if(!This.buffers[0]){
			err("Аудио буферы освобождены");
			return;
		};
		if(!This[set.type]){
			err("Не загружено"+set.type+"Кодировщик");
			return;
		};
		
		//Проверка конфигурации среды, здесь только для фиктивных вызовов, поскольку open уже проверил
		if(This.isMock){
			var checkMsg=This.envCheck(This.mockEnvInfo||{envName:"mock",canProcess:false});//没有提供环境信息的mock时没有onProcess回调
			if(checkMsg){
				err("Ошибка записи："+checkMsg);
				return;
			};
		};
		
		//Этот тип поддерживает запись и перекодирование (Worker)
		var engineCtx=This.engineCtx;
		if(This[set.type+"_complete"]&&engineCtx){
			var duration=Math.round(engineCtx.pcmSize/set[sampleRateTxt]*1000);//Длина принятых данных и длина буферов могут немного не совпадать, что является проблемой точности непрерывного преобразования частоты дискретизации
			
			t1=Date.now();
			This[set.type+"_complete"](engineCtx,function(blob){
				ok(blob,duration);
			},err);
			return;
		};
		
		//Стандартное перекодирование потока пользовательского интерфейса, настройка частоты дискретизации
		t1=Date.now();
		var chunk=Recorder.SampleData(This.buffers,This[srcSampleRateTxt],set[sampleRateTxt]);
		
		set[sampleRateTxt]=chunk[sampleRateTxt];
		var res=chunk.data;
		var duration=Math.round(res.length/set[sampleRateTxt]*1000);
		
		This.CLog("采样"+size+"->"+res.length+" 花:"+(Date.now()-t1)+"ms");
		
		setTimeout(function(){
			t1=Date.now();
			This[set.type](res,function(blob){
				ok(blob,duration);
			},function(msg){
				err(msg);
			});
		});
	}

};

if(window[RecTxt]){
	CLog("Повторное введение"+RecTxt,3);
	window[RecTxt].Destroy();
};
window[RecTxt]=Recorder;




//=======从WebM字节流中提取pcm数据，提取成功返回Float32Array，失败返回null||-1=====
var WebM_Extract=function(inBytes, scope){
	if(!scope.pos){
		scope.pos=[0]; scope.tracks={}; scope.bytes=[];
	};
	var tracks=scope.tracks, position=[scope.pos[0]];
	var endPos=function(){ scope.pos[0]=position[0] };
	
	var sBL=scope.bytes.length;
	var bytes=new Uint8Array(sBL+inBytes.length);
	bytes.set(scope.bytes); bytes.set(inBytes,sBL);
	scope.bytes=bytes;
	
	//先读取文件头和Track信息
	if(!scope._ht){
		readMatroskaVInt(bytes, position);//EBML Header
		readMatroskaBlock(bytes, position);//跳过EBML Header内容
		if(!BytesEq(readMatroskaVInt(bytes, position), [0x18,0x53,0x80,0x67])){
			return;//未识别到Segment
		}
		readMatroskaVInt(bytes, position);//Пропустить значение длины сегмента
		while(position[0]<bytes.length){
			var eid0=readMatroskaVInt(bytes, position);
			var bytes0=readMatroskaBlock(bytes, position);
			var pos0=[0],audioIdx=0;
			if(!bytes0)return;//Данные неполны, ожидают буферизации
			//Track: Полные данные, циклическое чтение TrackEntry
			if(BytesEq(eid0, [0x16,0x54,0xAE,0x6B])){
				while(pos0[0]<bytes0.length){
					var eid1=readMatroskaVInt(bytes0, pos0);
					var bytes1=readMatroskaBlock(bytes0, pos0);
					var pos1=[0],track={channels:0,sampleRate:0};
					if(BytesEq(eid1, [0xAE])){//TrackEntry
						while(pos1[0]<bytes1.length){
							var eid2=readMatroskaVInt(bytes1, pos1);
							var bytes2=readMatroskaBlock(bytes1, pos1);
							var pos2=[0];
							if(BytesEq(eid2, [0xD7])){//Track Number
								var val=BytesInt(bytes2);
								track.number=val;
								tracks[val]=track;
							}else if(BytesEq(eid2, [0x83])){//Track Type
								var val=BytesInt(bytes2);
								if(val==1) track.type="video";
								else if(val==2) {
									track.type="audio";
									if(!audioIdx) scope.track0=track;
									track.idx=audioIdx++;
								}else track.type="Type-"+val;
							}else if(BytesEq(eid2, [0x86])){//Track Codec
								var str="";
								for(var i=0;i<bytes2.length;i++){
									str+=String.fromCharCode(bytes2[i]);
								}
								track.codec=str;
							}else if(BytesEq(eid2, [0xE1])){
								while(pos2[0]<bytes2.length){//Просмотр свойств аудио
									var eid3=readMatroskaVInt(bytes2, pos2);
									var bytes3=readMatroskaBlock(bytes2, pos2);
									//Частота дискретизации, количество бит, количество каналов
									if(BytesEq(eid3, [0xB5])){
										var val=0,arr=new Uint8Array(bytes3.reverse()).buffer;
										if(bytes3.length==4) val=new Float32Array(arr)[0];
										else if(bytes3.length==8) val=new Float64Array(arr)[0];
										else CLog("WebM Track !Float",1,bytes3);
										track[sampleRateTxt]=Math.round(val);
									}else if(BytesEq(eid3, [0x62,0x64])) track.bitDepth=BytesInt(bytes3);
									else if(BytesEq(eid3, [0x9F])) track.channels=BytesInt(bytes3);
								}
							}
						}
					}
				};
				scope._ht=1;
				CLog("WebM Tracks",tracks);
				endPos();
				break;
			}
		}
	}
	
	//Проверка информации о параметрах звука.
	// Если она не соответствует требованиям кодекса, он будет отклонен.
	var track0=scope.track0;
	if(!track0)return;
	if(track0.bitDepth==16 && /FLOAT/i.test(track0.codec)){
		track0.bitDepth=32; //chrome v66 - Фактическое число с плавающей точкой
		CLog("WebM 16改32位",3);
	}
	if(track0[sampleRateTxt]!=scope[sampleRateTxt] || track0.bitDepth!=32 || track0.channels<1 || !/(\b|_)PCM\b/i.test(track0.codec)){
		scope.bytes=[];//Неожиданный формат. Невозможно обработать. Надо Очистить буферизованные данные.
		if(!scope.bad)CLog("Непредвиденный WebM Track ",3,scope);
		scope.bad=1;
		return -1;
	}
	
	//Цикл по SimpleBlocks в кластере
	var datas=[],dataLen=0;
	while(position[0]<bytes.length){
		var eid1=readMatroskaVInt(bytes, position);
		var bytes1=readMatroskaBlock(bytes, position);
		if(!bytes1) break;//Данные неполные, ожидают буферизации
		if(BytesEq(eid1, [0xA3])){//Полные данные SimpleBlock
			var trackNo=bytes1[0]&0xf;
			var track=tracks[trackNo];
			if(!track){//Это невозможно, данные неверны?
				CLog("WebM !Track"+trackNo,1,tracks);
			}else if(track.idx===0){
				var u8arr=new Uint8Array(bytes1.length-4);
				for(var i=4;i<bytes1.length;i++){
					u8arr[i-4]=bytes1[i];
				}
				datas.push(u8arr); dataLen+=u8arr.length;
			}
		}
		endPos();
	}
	
	if(dataLen){
		var more=new Uint8Array(bytes.length-scope.pos[0]);
		more.set(bytes.subarray(scope.pos[0]));
		scope.bytes=more; //Очистить буферизованные данные, которые были прочитаны
		scope.pos[0]=0;
		
		var u8arr=new Uint8Array(dataLen); //Полученные аудиоданные
		for(var i=0,i2=0;i<datas.length;i++){
			u8arr.set(datas[i],i2);
			i2+=datas[i].length;
		}
		var arr=new Float32Array(u8arr.buffer);
		
		if(track0.channels>1){//Многоканальный, извлечь один канал
			var arr2=[];
			for(var i=0;i<arr.length;){
				arr2.push(arr[i]);
				i+=track0.channels;
			}
			arr=new Float32Array(arr2);
		};
		return arr;
	}
};
//Одинаково ли содержимое двух байтовых массивов?
var BytesEq=function(bytes1,bytes2){
	if(!bytes1 || bytes1.length!=bytes2.length) return false;
	if(bytes1.length==1) return bytes1[0]==bytes2[0];
	for(var i=0;i<bytes1.length;i++){
		if(bytes1[i]!=bytes2[i]) return false;
	}
	return true;
};
//Преобразовать массив байтов BE в целое число
var BytesInt=function(bytes){
	var s="";//0-8 байт, битовая операция js поддерживает только 4 байта
	for(var i=0;i<bytes.length;i++){var n=bytes[i];s+=(n<16?"0":"")+n.toString(16)};
	return parseInt(s,16)||0;
};
//Прочитать числовой байтовый массив переменной длины
var readMatroskaVInt=function(arr,pos,trim){
	var i=pos[0];
	if(i>=arr.length)return;
	var b0=arr[i],b2=("0000000"+b0.toString(2)).substr(-8);
	var m=/^(0*1)(\d*)$/.exec(b2);
	if(!m)return;
	var len=m[1].length, val=[];
	if(i+len>arr.length)return;
	for(var i2=0;i2<len;i2++){ val[i2]=arr[i]; i++; }
	if(trim) val[0]=parseInt(m[2]||'0',2);
	pos[0]=i;
	return val;
};
//Прочитать массив байтов содержимого с собственной длиной
var readMatroskaBlock=function(arr,pos){
	var lenVal=readMatroskaVInt(arr,pos,1);
	if(!lenVal)return;
	var len=BytesInt(lenVal);
	var i=pos[0], val=[];
	if(len<0x7FFFFFFF){ //Увеличенное значение означает отсутствие длины.
		if(i+len>arr.length)return;
		for(var i2=0;i2<len;i2++){ val[i2]=arr[i]; i++; }
	}
	pos[0]=i;
	return val;
};
//===== End WebM =====




//Статистика трафика использует адрес изображения размером 1 пиксель. Если значение пустое, оно не будет включено в статистику.
Recorder.TrafficImgUrl="//ia.51.la/go1?id=20469973&pvFlag=1";
var Traffic=Recorder.Traffic=function(report){
	report=report?"/"+RecTxt+"/Report/"+report:"";
	var imgUrl=Recorder.TrafficImgUrl;
	if(imgUrl){
		var data=Recorder.Traffic;
		var m=/^(https?:..[^\/#]*\/?)[^#]*/i.exec(location.href)||[];
		var host=(m[1]||"http://file/");
		var idf=(m[0]||host)+report;
		
		if(imgUrl.indexOf("//")==0){
			//Добавьте префикс http к url. Если это файловый протокол, то без префикса он работать не будет.
			if(/^https:/i.test(idf)){
				imgUrl="https:"+imgUrl;
			}else{
				imgUrl="http:"+imgUrl;
			};
		};
		if(report){
			imgUrl=imgUrl+"&cu="+encodeURIComponent(host+report);
		};
		
		if(!data[idf]){
			data[idf]=1;
			
			var img=new Image();
			img.src=imgUrl;
			CLog("Traffic Analysis Image: "+(report||RecTxt+".TrafficImgUrl="+Recorder.TrafficImgUrl));
		};
	};
};

}));