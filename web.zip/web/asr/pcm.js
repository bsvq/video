/*
PCM-кодер + движок кодирования
https://github.com/xiangyuecn/Recorder

Принцип кодирования: Данные формата PCM, выводимые этим кодером, на самом деле являются исходными данными буферов в Recorder (после передискретизации). Когда они 16 бит, они находятся в режиме LE little endian (Little Endian) и не были закодированы.


Код кодирования не сильно отличается от wav.js. PCM плюс 44-байтовый заголовок WAV становится файлом WAV. Поэтому воспроизводить PCM очень просто. Просто преобразуйте его в файл WAV для воспроизведения. Предоставляется функция преобразования Recorder.pcm2wav.
*/
(function(){
"use strict";

Recorder.prototype.enc_pcm={
	stable:true
	,testmsg:"PCM — это неупакованные необработанные аудиоданные, и файлы данных PCM не могут быть воспроизведены напрямую; поддерживаемые числа бит — 8 и 16 бит (заполняется в битрейте), а значение частоты дискретизации не ограничено."
};
Recorder.prototype.pcm=function(res,True,False){
		var This=this,set=This.set
			,size=res.length
			,bitRate=set.bitRate==8?8:16;
		
		var buffer=new ArrayBuffer(size*(bitRate/8));
		var data=new DataView(buffer);
		var offset=0;
		
		// Запись выбранных данных
		if(bitRate==8) {
			for(var i=0;i<size;i++,offset++) {
				//16 к 8, принадлежит Лэй Сяохуа https://blog.csdn.net/sevennight1989/article/details/85376149 Это яснее, чем у пропорционального алгоритма blqw, хотя есть очевидный шум
				var val=(res[i]>>8)+128;
				data.setInt8(offset,val,true);
			};
		}else{
			for (var i=0;i<size;i++,offset+=2){
				data.setInt16(offset,res[i],true);
			};
		};
		
		
		True(new Blob([data.buffer],{type:"audio/pcm"}));
	};





/**pcm напрямую транскодируется в wav, который можно использовать для непосредственного воспроизведения; одновременно необходимо внедрить wav.js
data: {
		sampleRate:16000 // Частота дискретизации PCM
		bitRate:16 // Количество бит PCM Значение: 8 или 16
		blob:blob  // Объект
	}
	// Если данные предоставляются напрямую, большой двоичный объект будет использовать конфигурацию по умолчанию 16 бит 16 кГц, которая используется только для тестирования.
True(wavBlob,duration)
False(msg)
**/
Recorder.pcm2wav=function(data,True,False){
	if(data.slice && data.type!=null){//Blob 测试用
		data={blob:data};
	};
	var sampleRate=data.sampleRate||16000,bitRate=data.bitRate||16;
	if(!data.sampleRate || !data.bitRate){
		console.warn("pcm2wav должен предоставить sampleRate и bitRate");
	};
	if(!Recorder.prototype.wav){
		False("pcm2wav должен сначала загрузить wav-кодер wav.js");
		return;
	};
	
	var reader=new FileReader();
	reader.onloadend=function(){
		var pcm;
		if(bitRate==8){
			//8位转成16位
			var u8arr=new Uint8Array(reader.result);
			pcm=new Int16Array(u8arr.length);
			for(var j=0;j<u8arr.length;j++){
				pcm[j]=(u8arr[j]-128)<<8;
			};
		}else{
			pcm=new Int16Array(reader.result);
		};
		
		Recorder({
			type:"wav"
			,sampleRate:sampleRate
			,bitRate:bitRate
		}).mock(pcm,sampleRate).stop(function(wavBlob,duration){
			True(wavBlob,duration);
		},False);
	};
	reader.readAsArrayBuffer(data.blob);
};



})();