const mic_btn = document.querySelector('#mic');
const speechStatus = document.querySelector('.recording_status');
const options = document.querySelector('.options');
const option_btn = document.querySelector('.options-toggle');

const video = document.getElementById("video");
const audio = document.getElementById("audio");
const statusDiv = document.getElementById("status");
const connectBtn = document.getElementById("connectBtn");
const saveOptions_btn = document.getElementById('saveOptions');
const urlWebRTC = document.getElementById("urlWebRTC");
const urlAudio = document.getElementById("urlAudio");
const urlStop = document.getElementById("urlStop");
urlWebRTC.value = localStorage.getItem("urlWebRTC");
urlAudio.value = localStorage.getItem("urlAudio") || "audio/upload";
urlStop.value = localStorage.getItem("urlStop") || "/human";

const input = document.getElementById('number-input');
const increaseBtn = document.getElementById('increase');
const decreaseBtn = document.getElementById('decrease');
input.value = localStorage.getItem("input") || 1.5;

// let whepSessionId;
// Конфигурация ICE (STUN + TURN при необходимости)
const config = {
	sdpSemantics: 'unified-plan',
	iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
};

let can_record = false;
let recorder = null;
let voice = [];
let open_options = false
let peerConnection;
let speaking = null;
let stopRecordingTimer;

mic_btn.addEventListener('click', ToggleMic);
option_btn.addEventListener('click', ToggleOptions);
saveOptions_btn.addEventListener('click', SaveOptions);

function SetupAudio() {
  console.log('Setup');
  if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
	navigator.mediaDevices
	  .getUserMedia({
		audio: true,
	  })
	  .then(SetupStream)
	  .catch((err) => {
		console.error(err);
	  });
  }
}
SetupAudio();

function stopRecording() {
	stopRecordingTimer = setTimeout(
		()=> {
			recorder.stop();
			speaking = null;
			mic_btn.classList.remove('is-recording');
			speechStatus.textContent = 'Ваш вопрос принят!';
			console.log('**** stop recording');
			/*if (recognizing) {
				stt.stop();
				recognizing = false;
			}*/
			can_record = false;
		}, 1000 * input.value
	)
}


function SetupStream(stream) {
	mic_btn.classList.add('can_record');
	const stream_options = { mimeType: 'audio/webm;codecs=opus' };
	let hark_options = {threshold: -50, interval: 10};
	let speechEvents = hark(stream, hark_options);

	recorder = new MediaRecorder(stream, stream_options);
	recorder.ondataavailable = (e) => {
		voice.push(e.data);
	};

	speechEvents.on('speaking', function() {
		console.log('speaking');
		clearTimeout(stopRecordingTimer);
		if (can_record ) {
			if (speaking === null) {
				recorder.start();
				mic_btn.classList.add('is-recording');
				speechStatus.textContent = 'Слушаю';
			}
		} else {
			speechStatus.textContent = 'Микрофон выключен';
		}
		speaking = true;
	});

	speechEvents.on('stopped_speaking', function() {
		console.log('stopped_speaking');
		speaking = false;
		if (can_record) {
			stopRecording()
		}

	});

	recorder.onstop = async (e) => {
		console.log('recorder_stoped');
		const voiceBlob = new Blob(voice, {type: 'audio/wav'});
		voice = [];
		// let base64Audio = await audioToBase64(voiceBlob);
		try {
			const response = await fetch(urlAudio.value,
				{ method: 'POST',
					body: voiceBlob
				})
			if (!response.ok) {
				const message = `An error has occured: ${response.status}`;
				throw new Error(message);
			}
			const answer = await response.json();
			console.log(answer);
		} catch (error) {
			console.log('Fetch error: ', error);
		}
	};

  can_record = true;
}

/*function audioToBase64(audioFile) {
	return new Promise((resolve, reject) => {
		let reader = new FileReader();
		reader.onerror = reject;
		reader.onload = (e) => resolve(e.target.result);
		reader.readAsDataURL(audioFile);
	});
}*/

function ToggleMic() {
	can_record = !can_record
	speechStatus.textContent = can_record? "Слушаю": "Микрофон выключен";
	mic_btn.classList.toggle('can_record');
}

function ToggleOptions() {

	open_options = !open_options;

  if (open_options) {
	  options.classList.add('open');
  } else {
	  options.classList.remove('open');
  }
}

function SaveOptions() {
localStorage.setItem("urlWebRTC", urlWebRTC.value);
localStorage.setItem("urlAudio", urlAudio.value);
localStorage.setItem("urlStop", urlStop.value);
}

function negotiate() {
	peerConnection.addTransceiver('video', { direction: 'recvonly' });
	peerConnection.addTransceiver('audio', { direction: 'recvonly' });
	return peerConnection.createOffer().then((offer) => {
		return peerConnection.setLocalDescription(offer);
	}).then(() => {
		// wait for ICE gathering to complete
		return new Promise((resolve) => {
			if (peerConnection.iceGatheringState === 'complete') {
				resolve();
			} else {
				const checkState = () => {
					if (peerConnection.iceGatheringState === 'complete') {
						peerConnection.removeEventListener('icegatheringstatechange', checkState);
						resolve();
					}
				};
				peerConnection.addEventListener('icegatheringstatechange', checkState);
			}
		});
	}).then(() => {
		const offer = peerConnection.localDescription;
		return fetch(urlWebRTC.value, {
			body: JSON.stringify({
				sdp: offer.sdp,
				type: offer.type,
			}),
			headers: {
				'Content-Type': 'application/json'
			},
			method: 'POST'
		});
	}).then((response) => {
		return response.json();
	}).then((answer) => {
		statusUpdate("Соединение установлено", "active");
		options.classList.remove('open');
		return peerConnection.setRemoteDescription(answer);
	}).catch((error) => {
		statusUpdate(`Ошибка: ${error.message}`, "error");
		console.error(error);
		connectBtn.disabled = false;

		if (peerConnection) {
			peerConnection.close();
			peerConnection = null;
		}
	});
}

// распознавание голоса
const stt = new STT();
let recognizing = false;
async function sttStart() {
	if (!recognizing) {
		try {
			await stt.start()
			recognizing = true
		} catch (e) {
			console.error("Error: " + e.message);
		}
	}
}

// stt.onStart()
stt.onEnd(() => recognizing = false);
/*stt.onResult((finalTranscript) => {
	// if(finalTranscript === 'stop')
		console.log('finalTranscript', finalTranscript);
});*/
stt.onPartialResult(async (interimTranscript) => {
	if(interimTranscript === 'stop') {
		console.log('interimTranscript', interimTranscript);
		try {
			const response = await fetch(urlStop.value, {
				header: 'Content-Type: application/json',
				method: 'POST',
				body: '{"interrupt":"true"}',
			})
			if (!response.ok) {
				const message = `An error has occured: ${response.status}`;
				throw new Error(message);
			}
		} catch (error) {
			console.log('Fetch error: ', error);
		}
	}

});
stt.onError((error) => {
	recognizing = false;
	console.error(error);
});


sttStart().then(()=> console.log('sttStart'));


function connect() {

	peerConnection = new RTCPeerConnection(config);

	// connect audio / video
	peerConnection.addEventListener('track', (evt) => {
		let options = {threshold: -50, interval: 200};
		let speechEvents = hark(evt.streams[0], options);
		speechEvents.on('speaking', function() {
			console.log('robot_speaking');
			can_record = false;
			mic_btn.classList.remove('can_record');
			mic_btn.classList.remove('is-recording');
			speechStatus.textContent = 'Отвечаю на вопрос';
		});

		speechEvents.on('stopped_speaking', function() {
			console.log('robot_stopped_speaking');
			can_record = true;
			mic_btn.classList.add('can_record');
			speechStatus.textContent = 'Начните говорить!';
		});

		if (evt.track.kind === 'video') {
			video.srcObject = evt.streams[0];
		} else {
			audio.srcObject = evt.streams[0];
		}
	});

	negotiate();
}

// Обновление статуса
function statusUpdate(message, className) {
	statusDiv.textContent = message;
	statusDiv.className = className;
}

// Инициализация
connectBtn.addEventListener("click", connect);

// Проверка поддержки WebRTC
if (!window.RTCPeerConnection) {
	statusUpdate("WebRTC не поддерживается", "error");
	connectBtn.disabled = true;
}

// Функция для обновления значения с учетом ограничений
function updateValue(newValue) {
	let value = parseFloat(newValue);

	// Проверка на минимальное и максимальное значение
	if (value < 0.5) value = 0.5;
	if (value > 3) value = 3;

	// Округление до ближайшего шага 0.5
	value = Math.round(value * 2) / 2;

	input.value = value;
}

// Обработчики для кнопок
increaseBtn.addEventListener('click', () => {
	updateValue(parseFloat(input.value) + 0.5);
});

decreaseBtn.addEventListener('click', () => {
	updateValue(parseFloat(input.value) - 0.5);
});

// Обработчик для ручного ввода
input.addEventListener('change', () => {
	updateValue(input.value);
});