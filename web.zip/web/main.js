const mic_btn = document.querySelector('#mic');
// const playback = document.querySelector('.playback');
const speechStatus = document.querySelector('.recording_status');
const options = document.querySelector('.options');
const option_btn = document.querySelector('.options-toggle');

const video = document.getElementById("video");
const audio = document.getElementById("audio");
const statusDiv = document.getElementById("status");
const connectBtn = document.getElementById("connectBtn");
const saveOptions_btn = document.getElementById('saveOptions');
const urlWebRTC = document.getElementById("urlWebRTC");
const urlAudio = document.getElementById("urlAudio");
const WHEP_URL = "http://172.24.100.199:1985/rtc/v1/whep/?app=rtc&stream=uid";
urlWebRTC.value = localStorage.getItem("urlWebRTC");
urlAudio.value = localStorage.getItem("urlAudio");
// let whepSessionId;
// Конфигурация ICE (STUN + TURN при необходимости)
const iceConfig = {
	iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
	sdpSemantics: 'unified-plan'
};
const config = {
	sdpSemantics: 'unified-plan'
};

let can_record = false;
let is_recording = false;
let recorder = null;
let chunks = [];
let open_options = false
let peerConnection;

mic_btn.addEventListener('click', ToggleMic);
option_btn.addEventListener('click', ToggleOptions);
saveOptions_btn.addEventListener('click', SaveOptions);

function SetupAudio() {
  console.log('Setup');
  if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
	navigator.mediaDevices
	  .getUserMedia({
		audio: true,
	  })
	  .then(SetupStream)
	  .catch((err) => {
		console.error(err);
	  });
  }
}
SetupAudio();

function SetupStream(stream) {
	mic_btn.classList.add('can_record');
	recorder = new MediaRecorder(stream);
	var options = {threshold: -50, interval: 100};
	var speechEvents = hark(stream, options);

	speechEvents.on('speaking', function() {
		console.log('speaking');
		recorder.start();
		mic_btn.classList.add('is-recording');
		speechStatus.textContent = 'Слушаю';
	});

	speechEvents.on('stopped_speaking', function() {
		console.log('stopped_speaking');
		recorder.stop();
		mic_btn.classList.remove('is-recording');
		speechStatus.textContent = 'Ваш вопрос принят!';
	});

	recorder = new MediaRecorder(stream);
	recorder.ondataavailable = (e) => {
		chunks.push(e.data);
	};

	recorder.onstop = async (e) => {
		const blob = new Blob(chunks, { type: 'audio/ogg; codecs=opus' });
		chunks = [];
		// const audioURL = window.URL.createObjectURL(blob);
		//playback.src = audioURL;
		let base64Audio = await audioToBase64(blob);
		console.log(base64Audio);
		/*await fetch(urlAudio.value, {
			method: 'POST',
			headers: {},
			body: base64Audio
		})*/
	};

  can_record = true;
}

function audioToBase64(audioFile) {
	return new Promise((resolve, reject) => {
		let reader = new FileReader();
		reader.onerror = reject;
		reader.onload = (e) => resolve(e.target.result);
		reader.readAsDataURL(audioFile);
	});
}

function ToggleMic() {
  if (!can_record) return;

  is_recording = !is_recording;

  if (is_recording) {
	recorder.start();
	mic_btn.classList.add('is-recording');
  } else {
	recorder.stop();
	mic_btn.classList.remove('is-recording');
  }
}

function ToggleOptions() {

	open_options = !open_options;

  if (open_options) {
	  options.classList.add('open');
  } else {
	  options.classList.remove('open');
  }
}

function SaveOptions() {
localStorage.setItem("urlWebRTC", urlWebRTC.value);
localStorage.urlAudio = urlAudio.value;
}

// Основная функция подключения
/*async function connect() {
	try {
		statusUpdate("Инициализация соединения...", "waiting");
		connectBtn.disabled = true;

		// 1. Создаем локальный PeerConnection
		peerConnection = new RTCPeerConnection(config);

		// Обработчик видеопотока
		peerConnection.ontrack = (event) => {
			if (event.streams.length) {
				remoteVideo.srcObject = event.streams[0];
				statusUpdate("Видеопоток активен", "active");
			}
		};

		// 2. Создаем локальный offer
		const offer = await peerConnection.createOffer({
			offerToReceiveAudio: true,
			offerToReceiveVideo: true,
		});
		await peerConnection.setLocalDescription(offer);

		// 3. Отправляем offer на WHEP сервер
		const response = await fetch(urlWebRTC.value, {
			body: JSON.stringify({
				sdp: offer.sdp,
				type: offer.type,
			}),
			headers: {
				'Content-Type': 'application/json'
			},
			method: 'POST'
		});

		if (!response.ok) throw new Error("Ошибка WHEP сервера");

		// 4. Получаем answer от сервера
		const answerSDP = await response.text();
		await peerConnection.setRemoteDescription({
			type: "answer",
			sdp: answerSDP,
		});

		statusUpdate("Соединение установлено", "active");
	} catch (error) {
		statusUpdate(`Ошибка: ${error.message}`, "error");
		console.error(error);
		connectBtn.disabled = false;

		if (peerConnection) {
			peerConnection.close();
			peerConnection = null;
		}
	}
}*/

function negotiate() {
	peerConnection.addTransceiver('video', { direction: 'recvonly' });
	peerConnection.addTransceiver('audio', { direction: 'recvonly' });
	return peerConnection.createOffer().then((offer) => {
		return peerConnection.setLocalDescription(offer);
	}).then(() => {
		// wait for ICE gathering to complete
		return new Promise((resolve) => {
			if (peerConnection.iceGatheringState === 'complete') {
				resolve();
			} else {
				const checkState = () => {
					if (peerConnection.iceGatheringState === 'complete') {
						peerConnection.removeEventListener('icegatheringstatechange', checkState);
						resolve();
					}
				};
				peerConnection.addEventListener('icegatheringstatechange', checkState);
			}
		});
	}).then(() => {
		const offer = peerConnection.localDescription;
		return fetch(urlWebRTC.value, {
			body: JSON.stringify({
				sdp: offer.sdp,
				type: offer.type,
			}),
			headers: {
				'Content-Type': 'application/json'
			},
			method: 'POST'
		});
	}).then((response) => {
		return response.json();
	}).then((answer) => {
		//document.getElementById('sessionid').value = answer.sessionid
		return peerConnection.setRemoteDescription(answer);
	}).catch((e) => {
		alert(e);
	});
}

function connect() {

	peerConnection = new RTCPeerConnection(config);

	// connect audio / video
	peerConnection.addEventListener('track', (evt) => {
		if (evt.track.kind === 'video') {
			video.srcObject = evt.streams[0];
		} else {
			audio.srcObject = evt.streams[0];
		}
	});
	negotiate();
}

// Обновление статуса
function statusUpdate(message, className) {
	statusDiv.textContent = message;
	statusDiv.className = className;
}

// Инициализация
connectBtn.addEventListener("click", connect);

// Проверка поддержки WebRTC
if (!window.RTCPeerConnection) {
	statusUpdate("WebRTC не поддерживается", "error");
	connectBtn.disabled = true;
}
